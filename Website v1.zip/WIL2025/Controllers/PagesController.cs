using Microsoft.AspNetCore.Mvc;

namespace WIL2025.Controllers
{
    public class PagesController : Controller
    {
        public IActionResult Training()
        {
            return View();
        }

        public IActionResult Qualifications()
        {
            return View();
        }

        public IActionResult SoupKitchen()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }
    }
}
